<html>
<head>
<title>
My First Web Application </title>
</head>
<body>
<?php
echo "Hello World";
?>
</body>
</html>